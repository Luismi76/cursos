package com.infocurso.backend.entity;

public enum Rol {
    ALUMNO,
    PROFESOR,
    ADMINISTRADOR
}


package com.infocurso.backend.dto;

import com.infocurso.backend.entity.TipoEvento;
import com.infocurso.backend.entity.VisibilidadEvento;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EventoCursoDTO {
    private String titulo;
    private String descripcion;
    private TipoEvento tipo;
    private VisibilidadEvento visiblePara;
    private LocalDate fecha;
}

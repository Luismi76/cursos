package com.infocurso.backend.entity;

public enum VisibilidadEvento {
    ADMIN, PROFESOR, ALUMNO
}

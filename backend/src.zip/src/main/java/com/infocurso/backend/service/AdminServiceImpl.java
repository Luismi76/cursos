package com.infocurso.backend.service;

import com.infocurso.backend.dto.*;
import com.infocurso.backend.entity.*;
import com.infocurso.backend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final CursoRepository cursoRepository;
    private final CursoService cursoService;
    private final UsuarioRepository usuarioRepository;
    private final ModuloRepository moduloRepository;
    private final UnidadFormativaRepository unidadRepository;
    private final EventoCursoRepository eventoRepository;

    @Override
    public CursoDTO crearCurso(CursoDTO dto) {
        Curso curso = Curso.builder()
                .nombre(dto.nombre())
                .descripcion(dto.descripcion())
                .build();
        curso = cursoRepository.save(curso);
        List<AlumnoDTO> alumnos = curso.getAlumnos() != null
                ? curso.getAlumnos().stream().map(AlumnoDTO::from).toList()
                : List.of();

        return CursoDTO.from(curso, alumnos);
    }

    @Override
    public void asignarProfesor(UUID cursoId, UUID profesorId) {
        Curso curso = cursoRepository.findById(cursoId)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));
        Usuario profesor = usuarioRepository.findById(profesorId)
                .orElseThrow(() -> new RuntimeException("Profesor no encontrado"));
        curso.setProfesor(profesor);
        cursoRepository.save(curso);
    }

    @Override
    public void matricularAlumno(UUID cursoId, UUID alumnoId) {
        Curso curso = cursoRepository.findById(cursoId)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));
        Usuario alumno = usuarioRepository.findById(alumnoId)
                .orElseThrow(() -> new RuntimeException("Alumno no encontrado"));
        curso.getAlumnos().add(alumno);
        cursoRepository.save(curso);
    }

    @Override
    public ModuloDTO agregarModulo(UUID cursoId, ModuloDTO dto) {
        Curso curso = cursoRepository.findById(cursoId)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

        Modulo modulo = new Modulo();
        modulo.setNombre(dto.getNombre());
        modulo.setFechaInicio(dto.getFechaInicio());
        modulo.setFechaFin(dto.getFechaFin());
        modulo.setCurso(curso);

        Modulo guardado = moduloRepository.save(modulo);
        return ModuloDTO.from(guardado);
    }

    @Override
    public void agregarUnidad(UUID moduloId, UnidadFormativaDTO dto) {
        Modulo modulo = moduloRepository.findById(moduloId)
                .orElseThrow(() -> new RuntimeException("Módulo no encontrado"));

        UnidadFormativa uf = UnidadFormativa.builder()
                .nombre(dto.getNombre())
                .fechaInicio(dto.getFechaInicio())
                .fechaFin(dto.getFechaFin())
                .modulo(modulo)
                .build();

        unidadRepository.save(uf);
    }

    @Override
    public void crearEventoAdmin(UUID cursoId, EventoCursoDTO dto) {
        Curso curso = cursoRepository.findById(cursoId)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

        EventoCurso evento = EventoCurso.builder()
                .titulo(dto.getTitulo())
                .descripcion(dto.getDescripcion())
                .fecha(dto.getFecha())
                .tipo(dto.getTipo())
                .visiblePara(dto.getVisiblePara())
                .curso(curso)
                .autor(null) // Se puede completar con el usuario autenticado
                .build();

        eventoRepository.save(evento);
    }

    public List<UsuarioDTO> listarProfesores() {
        return usuarioRepository.findProfesores()
                .stream()
                .map(UsuarioDTO::from)
                .toList();
    }


}

package com.infocurso.backend.service;

import com.infocurso.backend.dto.*;

import java.util.List;
import java.util.UUID;

public interface AdminService {
    CursoDTO crearCurso(CursoDTO dto);
    void asignarProfesor(UUID cursoId, UUID profesorId);
    void matricularAlumno(UUID cursoId, UUID alumnoId);
    ModuloDTO agregarModulo(UUID cursoId, ModuloDTO dto);
    void agregarUnidad(UUID moduloId, UnidadFormativaDTO dto);
    void crearEventoAdmin(UUID cursoId, EventoCursoDTO dto);
    List<UsuarioDTO> listarProfesores();
}

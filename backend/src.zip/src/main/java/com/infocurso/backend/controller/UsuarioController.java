package com.infocurso.backend.controller;
import com.infocurso.backend.dto.PerfilDTO;
import com.infocurso.backend.dto.UsuarioDTO;
import com.infocurso.backend.entity.UserPrincipal;
import com.infocurso.backend.entity.Usuario;
import com.infocurso.backend.service.UsuarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/usuarios")
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService usuarioService;

    @PostMapping
    public Usuario registrarUsuario(@RequestBody Usuario usuario) {
        return usuarioService.save(usuario);
    }

    @GetMapping("/{id}")
    public Usuario getUsuarioPorId(@PathVariable UUID id) {
        return usuarioService.getById(id);
    }

    @GetMapping("/buscar")
    public Optional<Usuario> buscarPorEmail(@RequestParam String email) {
        return usuarioService.getByEmail(email);
    }

    @GetMapping
    public List<Usuario> listarTodos() {
        return usuarioService.findAll();
    }

    @GetMapping("/perfil")
    public PerfilDTO obtenerPerfil(@AuthenticationPrincipal UserPrincipal principal) {
        return PerfilDTO.from(principal.getUsuario());
    }

    @PutMapping("/perfil")
    public PerfilDTO actualizarPerfil(@AuthenticationPrincipal UserPrincipal principal, @RequestBody Map<String, String> body) {
        Usuario usuario = principal.getUsuario();
        String nuevoNombre = body.get("nombre");
        String avatarUrl = body.get("avatarUrl"); // puede ser base64 o una URL subida

        if (nuevoNombre != null) usuario.setNombre(nuevoNombre);
        if (avatarUrl != null) usuario.setAvatarUrl(avatarUrl);

        usuario = usuarioService.save(usuario);
        return PerfilDTO.from(usuario);
    }

    @PostMapping("/avatar")
    public ResponseEntity<String> subirAvatar(@RequestParam("file") MultipartFile file,
                                              @AuthenticationPrincipal UserPrincipal principal) throws IOException {
        usuarioService.actualizarAvatar(principal.getUsuario().getId(), file);
        return ResponseEntity.ok("Avatar actualizado");
    }

    @GetMapping("/me")
    public UsuarioDTO getPerfil(@AuthenticationPrincipal UserPrincipal principal) {
        return UsuarioDTO.from(principal.getUsuario());
    }
}

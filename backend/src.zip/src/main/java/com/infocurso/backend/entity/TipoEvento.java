package com.infocurso.backend.entity;

public enum TipoEvento {
    INICIO_CURSO, FIN_CURSO,
    INICIO_MODULO, FIN_MODULO,
    INICIO_UF, FIN_UF,
    ENTREGA, EVALUACION, OTRO
}

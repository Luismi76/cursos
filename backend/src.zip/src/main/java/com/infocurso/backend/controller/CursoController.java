package com.infocurso.backend.controller;
import com.infocurso.backend.dto.CursoDTO;
import com.infocurso.backend.entity.Curso;
import com.infocurso.backend.service.CursoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/cursos")
@RequiredArgsConstructor
public class CursoController {

    private final CursoService cursoService;

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ALUMNO', 'PROFESOR', 'ADMINISTRADOR')")
    public ResponseEntity<?> obtenerCurso(@PathVariable UUID id) {
        try {
            CursoDTO dto = cursoService.getCursoDTO(id);
            return ResponseEntity.ok(dto);
        } catch (Exception e) {
            e.printStackTrace(); // MUY IMPORTANTE
            return ResponseEntity.status(500).body(Map.of(
                    "error", "Error al cargar el curso",
                    "mensaje", e.getMessage()
            ));
        }
    }


    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('PROFESOR')")
    public void eliminarCurso(@PathVariable UUID id) {
        cursoService.eliminarCurso(id);
    }
}


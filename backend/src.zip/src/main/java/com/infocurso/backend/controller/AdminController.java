package com.infocurso.backend.controller;

import com.infocurso.backend.dto.*;
import com.infocurso.backend.service.AdminService;
import com.infocurso.backend.service.AlumnoCursoService;
import com.infocurso.backend.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMINISTRADOR')")
public class AdminController {

    @Autowired
    private AdminService adminService;
    @Autowired
    private CursoService cursoService;
    @Autowired
    private AlumnoCursoService alumnoCursoService;

    @PostMapping("/curso")
    public ResponseEntity<CursoDTO> crearCurso(@RequestBody CursoDTO dto) {
        return ResponseEntity.ok(adminService.crearCurso(dto));
    }

    @PostMapping("/curso/{cursoId}/profesor/{profesorId}")
    public void asignarProfesor(@PathVariable UUID cursoId, @PathVariable UUID profesorId) {
        adminService.asignarProfesor(cursoId, profesorId);
    }

    @PostMapping("/curso/{cursoId}/alumno/{alumnoId}")
    public void matricularAlumno(@PathVariable UUID cursoId, @PathVariable UUID alumnoId) {
        adminService.matricularAlumno(cursoId, alumnoId);
    }

    @PostMapping("/curso/{cursoId}/modulo")
    public ModuloDTO agregarModulo(@PathVariable UUID cursoId, @RequestBody ModuloDTO dto) {
        return adminService.agregarModulo(cursoId, dto);
    }

    @PostMapping("/modulo/{moduloId}/unidad")
    public void agregarUnidad(@PathVariable UUID moduloId, @RequestBody UnidadFormativaDTO dto) {
        adminService.agregarUnidad(moduloId, dto);
    }

    @PostMapping("/curso/{cursoId}/evento")
    public void crearEventoAdmin(@PathVariable UUID cursoId, @RequestBody EventoCursoDTO dto) {
        adminService.crearEventoAdmin(cursoId, dto);
    }
    @GetMapping("/cursos")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public List<CursoDTO> listarCursos() {
        return cursoService.getTodosLosCursos();
    }
    @GetMapping("/profesores")
    public ResponseEntity<List<UsuarioDTO>> listarProfesores() {
        return ResponseEntity.ok(adminService.listarProfesores());
    }
    @GetMapping("/curso/{cursoId}/alumnos-disponibles")
    public List<AlumnoDTO> listarAlumnosDisponiblesAdmin(@PathVariable UUID cursoId) {
        return alumnoCursoService.listarAlumnosNoInscritosEnCurso(cursoId)
                .stream()
                .map(AlumnoDTO::from)
                .toList();
    }

    @GetMapping("/curso/{cursoId}/alumnos")
    public List<AlumnoDTO> listarAlumnosCurso(@PathVariable UUID cursoId) {
        return alumnoCursoService.listarAlumnosPorCurso(cursoId)
                .stream()
                .map(AlumnoDTO::from)
                .toList();
    }
    @GetMapping("/curso/{cursoId}")
    public CursoDTO obtenerCurso(@PathVariable UUID cursoId) {
        return cursoService.getCursoDTO(cursoId);
    }
}


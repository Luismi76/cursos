package com.infocurso.backend.controller;

import com.infocurso.backend.dto.AlumnoDTO;
import com.infocurso.backend.dto.CursoDTO;
import com.infocurso.backend.dto.EntregasAgrupadasDTO;
import com.infocurso.backend.dto.NotificacionDTO;
import com.infocurso.backend.entity.Curso;
import com.infocurso.backend.entity.UserPrincipal;
import com.infocurso.backend.entity.Usuario;
import com.infocurso.backend.repository.CursoRepository;
import com.infocurso.backend.service.AlumnoCursoService;
import com.infocurso.backend.service.CursoService;
import com.infocurso.backend.service.EntregaPracticaService;
import com.infocurso.backend.service.NotificacionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/alumno")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ALUMNO')")
public class AlumnoController {

    private final AlumnoCursoService alumnoCursoService;
    private final CursoService cursoService;
    private final CursoRepository cursoRepository;
    private final NotificacionService notificacionService;
    private final EntregaPracticaService entregaPracticaService;


    @GetMapping("/cursos")
    public List<CursoDTO> getCursosDelAlumno(@AuthenticationPrincipal UserPrincipal principal) {
        Usuario alumno = principal.getUsuario();

        return alumnoCursoService.getCursosDelAlumno(alumno.getId())
                .stream()
                .map(curso -> CursoDTO.from(curso, List.of())) // ← lista de alumnos vacía
                .toList();
    }
    @GetMapping("/curso/{cursoId}")
    public CursoDTO getCursoDelAlumno(
            @PathVariable UUID cursoId,
            @AuthenticationPrincipal UserPrincipal principal
    ) {
        Usuario alumno = principal.getUsuario();

        // Verificamos si está inscrito
        boolean inscrito = alumnoCursoService.estaInscrito(cursoId, alumno.getId());
        if (!inscrito) {
            throw new RuntimeException("El alumno no está inscrito en este curso.");
        }

        // Obtener curso con prácticas y alumnos
        return cursoService.getCursoConPrácticasYAlumnos(cursoId);
    }
    public CursoDTO getCursoConPrácticasYAlumnos(UUID cursoId) {
        Curso curso = cursoRepository.findByIdConRelaciones(cursoId)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

        // Obtener alumnos del curso
        List<Usuario> alumnos = alumnoCursoService.listarAlumnosPorCurso(cursoId);

        // Convertir a AlumnoDTO
        List<AlumnoDTO> alumnoDTOs = alumnos.stream()
                .map(AlumnoDTO::from)
                .toList();

        return CursoDTO.from(curso, alumnoDTOs);
    }

    @PutMapping("/notificaciones/{id}/leida")
    public ResponseEntity<Void> marcarComoLeida(@PathVariable UUID id, @AuthenticationPrincipal UserPrincipal principal) {
        notificacionService.marcarComoLeida(id, principal.getUsuario().getId());
        return ResponseEntity.ok().build();
    }

    @GetMapping("/notificaciones")
    public List<NotificacionDTO> getNotificaciones(@AuthenticationPrincipal UserPrincipal principal) {
        return notificacionService.getNotificacionesDeUsuario(principal.getUsuario().getId());
    }

    @GetMapping("/curso/{cursoId}/historial")
    public EntregasAgrupadasDTO getHistorialCurso(
            @PathVariable UUID cursoId,
            @AuthenticationPrincipal UserPrincipal principal
    ) {
        Usuario alumno = principal.getUsuario();

        // 🔒 Verifica que está inscrito en el curso
        if (!alumnoCursoService.estaInscrito(cursoId, alumno.getId())) {
            throw new RuntimeException("No estás inscrito en este curso.");
        }

        return entregaPracticaService.getHistorialAlumnoPorCurso(cursoId, alumno.getId());
    }

}


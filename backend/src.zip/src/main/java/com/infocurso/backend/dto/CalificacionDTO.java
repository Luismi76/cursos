package com.infocurso.backend.dto;

import lombok.Data;

@Data
public class CalificacionDTO {
    private Double nota;
    private String comentarioProfesor;
}


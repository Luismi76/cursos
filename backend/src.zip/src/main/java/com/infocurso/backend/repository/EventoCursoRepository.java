package com.infocurso.backend.repository;

import com.infocurso.backend.entity.EventoCurso;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface EventoCursoRepository extends JpaRepository<EventoCurso, UUID> {
}


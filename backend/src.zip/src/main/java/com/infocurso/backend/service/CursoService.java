package com.infocurso.backend.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infocurso.backend.dto.AlumnoDTO;
import com.infocurso.backend.dto.CrearPracticaDTO;
import com.infocurso.backend.dto.CursoDTO;
import com.infocurso.backend.dto.ModuloDTO;
import com.infocurso.backend.entity.Curso;
import com.infocurso.backend.entity.Practica;
import com.infocurso.backend.entity.UserPrincipal;
import com.infocurso.backend.entity.Usuario;
import com.infocurso.backend.repository.CursoRepository;
import com.infocurso.backend.repository.PracticaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CursoService {

    private final CursoRepository cursoRepository;
    private final PracticaRepository practicaRepository;
    private final AlumnoConsultaService alumnoConsultaService;
    private final ObjectMapper objectMapper;

    public Curso crearCurso(CursoDTO dto, Usuario profesor) {
        Curso curso = new Curso();
        curso.setNombre(dto.nombre());
        curso.setDescripcion(dto.descripcion());
        curso.setProfesor(profesor); // aquí asocias el curso al profesor autenticado
        return cursoRepository.save(curso);
    }

    public List<Curso> getCursosDelProfesor(UUID profesorId) {
        return cursoRepository.findByProfesorId(profesorId);
    }

    public CursoDTO getCursoById(UUID cursoId) {
        Curso curso = cursoRepository.findByIdConRelaciones(cursoId)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

        List<AlumnoDTO> alumnos = curso.getAlumnos().stream()
                .map(AlumnoDTO::from)
                .toList();

        return CursoDTO.from(curso, alumnos);
    }

    public void eliminarCurso(UUID cursoId) {
        cursoRepository.deleteById(cursoId);
    }

    public List<Curso> findByProfesor(Usuario profesor) {
        return cursoRepository.findByProfesor(profesor);
    }

    public List<Curso> listarCursos() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserPrincipal userPrincipal) {
            Usuario profesor = userPrincipal.getUsuario();
            return cursoRepository.findByProfesor(profesor);
        }
        throw new RuntimeException("Usuario no autenticado o tipo incorrecto");
    }

    public Practica crearPractica(Curso curso, String titulo, String descripcion, LocalDateTime fechaEntrega) {
        Practica practica = Practica.builder()
                .curso(curso)
                .titulo(titulo)
                .descripcion(descripcion)
                .fechaEntrega(fechaEntrega)
                .build();
        return practicaRepository.save(practica);
    }

    public CursoDTO getCursoConPrácticasYAlumnos(UUID cursoId) {
        Curso curso = cursoRepository.findByIdConRelaciones(cursoId)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

        List<AlumnoDTO> alumnos = alumnoConsultaService.listarAlumnosPorCurso(cursoId);

        return CursoDTO.from(curso, alumnos);
    }
    public void eliminarPractica(UUID practicaId) {
        practicaRepository.deleteById(practicaId);
    }

    public Practica editarPractica(UUID practicaId, CrearPracticaDTO dto) {
        Practica practica = practicaRepository.findById(practicaId)
                .orElseThrow(() -> new RuntimeException("Práctica no encontrada"));

        try {
            practica.setTitulo(dto.titulo());
            practica.setDescripcion(objectMapper.writeValueAsString(dto.descripcion()));
            practica.setFechaEntrega(dto.fechaEntrega());
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error al serializar la descripción", e);
        }

        return practicaRepository.save(practica);
    }
    public CursoDTO getCursoDTO(UUID id) {
        System.out.println("🟢 Intentando cargar curso: " + id);

        Curso curso = cursoRepository.findByIdConRelaciones(id)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

        try {
            List<AlumnoDTO> alumnos = curso.getAlumnos() != null
                    ? curso.getAlumnos().stream().map(AlumnoDTO::from).toList()
                    : List.of();

            return CursoDTO.from(curso, alumnos);
        } catch (Exception e) {
            System.out.println("❌ Error al construir CursoDTO: " + e.getMessage());
            throw e;
        }
    }




    public List<CursoDTO> getTodosLosCursos() {
        return cursoRepository.findAllConRelaciones().stream()
                .map(curso -> CursoDTO.from(
                        curso,
                        curso.getAlumnos().stream().map(AlumnoDTO::from).toList()
                ))
                .toList();
    }


}


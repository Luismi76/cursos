package com.infocurso.backend.controller;

import com.infocurso.backend.entity.Rol;
import com.infocurso.backend.entity.Usuario;
import com.infocurso.backend.security.JwtUtil;
import com.infocurso.backend.service.UsuarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UsuarioService usuarioService;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String password = body.get("password");

        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(email, password)
        );

        Usuario user = (Usuario) auth.getPrincipal();
        String token = jwtUtil.generarToken(user.getEmail(), user.getId(), user.getRol().name());

        return ResponseEntity.ok(Map.of(
                "token", token,
                "user", Map.of(
                        "id", user.getId(),
                        "nombre", user.getNombre(),
                        "rol", user.getRol().name() // 👈 importante
                )
        ));
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registrar(@RequestBody Map<String, String> body) {
        String nombre = body.get("nombre");
        String email = body.get("email");
        String password = body.get("password");

        Usuario nuevo = Usuario.builder()
                .nombre(nombre)
                .email(email)
                .passwordHash(passwordEncoder.encode(password))
                .rol(Rol.ALUMNO)
                .build();

        usuarioService.save(nuevo);

        String token = jwtUtil.generarToken(nuevo.getEmail(), nuevo.getId(), nuevo.getRol().name());

        return ResponseEntity.ok(Map.of("token", token));
    }
}

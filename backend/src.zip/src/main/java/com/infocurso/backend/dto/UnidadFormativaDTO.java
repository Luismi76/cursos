package com.infocurso.backend.dto;

import com.infocurso.backend.entity.UnidadFormativa;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnidadFormativaDTO {

    private String nombre;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;

    public static UnidadFormativaDTO from(UnidadFormativa unidad) {
        return UnidadFormativaDTO.builder()
                .nombre(unidad.getNombre())
                .fechaInicio(unidad.getFechaInicio())
                .fechaFin(unidad.getFechaFin())
                .build();
    }

    public UnidadFormativa toEntity() {
        UnidadFormativa unidad = new UnidadFormativa();
        unidad.setNombre(this.nombre);
        unidad.setFechaInicio(this.fechaInicio);
        unidad.setFechaFin(this.fechaFin);
        return unidad;
    }
}

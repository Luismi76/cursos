package com.infocurso.backend.dto;

import com.infocurso.backend.entity.Curso;
import lombok.Builder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

@Builder
public record CursoDTO(
        UUID id,
        String nombre,
        String descripcion,
        String profesorNombre,
        List<AlumnoDTO> alumnos,
        List<PracticaDTO> practicas,
        List<ModuloDTO> modulos
) {
    public static CursoDTO from(Curso curso, List<AlumnoDTO> alumnos) {
        List<PracticaDTO> practicas = curso.getPracticas() != null
                ? curso.getPracticas().stream()
                .map(PracticaDTO::from)
                .toList()
                : Collections.emptyList();

        List<ModuloDTO> modulos = curso.getModulos() != null
                ? new ArrayList<>(curso.getModulos()).stream()
                .map(ModuloDTO::from)
                .toList()
                : Collections.emptyList();


        String profesorNombre = curso.getProfesor() != null
                ? curso.getProfesor().getNombre()
                : null;

        return new CursoDTO(
                curso.getId(),
                curso.getNombre(),
                curso.getDescripcion(),
                profesorNombre,
                alumnos != null ? alumnos : Collections.emptyList(),
                practicas,
                modulos
        );
    }
}

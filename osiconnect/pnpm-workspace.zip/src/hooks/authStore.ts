import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Perfil } from '@/lib/types'

interface AuthState {
  usuario: Perfil | null
  setUser: (u: Perfil) => void
  logout: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      usuario: null,
      setUser: (usuario) => set({ usuario }),
      logout: () => {
        localStorage.removeItem("token");
        set({ usuario: null });
      },
    }),
    {
      name: 'auth',
    }
  )
)

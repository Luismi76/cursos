// src/hooks/useChatCursoSocket.ts
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

export function createChatCursoSocket(
  cursoId: string,
  onMessage: (msg: any) => void,
  onConnected: () => void
) {
  const client = new Client({
    webSocketFactory: () => new SockJS(`${process.env.NEXT_PUBLIC_API_URL}/ws-chat`),
    onConnect: () => {
      client.subscribe(`/topic/curso/${cursoId}`, (msg) => {
        const parsed = JSON.parse(msg.body);
        console.log("📥 Mensaje recibido por WebSocket:", parsed); 
        onMessage(parsed);
      });
      onConnected();
    },
    debug: (str) => console.log('[STOMP]', str),
    reconnectDelay: 5000,
  });

  client.activate();
  return client;
}

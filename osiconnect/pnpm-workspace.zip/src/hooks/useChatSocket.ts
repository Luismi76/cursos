import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

export function createChatSocket(
  userId: string,
  onMessage: (msg: any) => void,
  onConnected: () => void
) {
  const client = new Client({
    webSocketFactory: () => new SockJS('http://localhost:8080/ws-chat'), // cambia a tu URL real
    onConnect: () => {
      client.subscribe('/user/queue/messages', (msg) => {
        const parsed = JSON.parse(msg.body);
        onMessage(parsed);
      });
      onConnected();
    },
    debug: str => console.log('[STOMP]', str),
    reconnectDelay: 5000,
  });

  client.activate();
  return client;
}

import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL!;
if (!API_URL) {
  throw new Error('Falta definir NEXT_PUBLIC_API_URL en el entorno');
}

// Instancia principal de axios
export const api = axios.create({
  baseURL: `${API_URL}`,
  headers: {
    // 'Content-Type': 'application/json',
  },
});

// Añade el token JWT en cada request automáticamente
api.interceptors.request.use(config => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
  }
  return config
})

// Función de login que obtiene el token
export const login = async (email: string, password: string) => {
  const response = await axios.post(
    `${API_URL}/auth/login`,
    { email, password },
    {
      headers: { 'Content-Type': 'application/json' },
      // ❌ NO withCredentials si usas JWT puro
    }
  );
  return response.data;
};

import { api } from './api'
import { Usuario } from '@/lib/types'

export const getPerfil = async (): Promise<Usuario> => {
  const res = await api.get('/usuarios/perfil')
  return res.data
}

export const actualizarPerfil = async (data: {
  nombre: string
  avatarUrl?: string
}): Promise<Usuario> => {
  const res = await api.put('/usuarios/perfil', data)
  return res.data
}

export const subirAvatar = async (file: File): Promise<string> => {
  const formData = new FormData();
  formData.append("file", file); // 👈 Este nombre debe coincidir con el @RequestParam("file")

  const res = await api.post("/usuarios/avatar", formData); // NO PONER headers aquí
  console.log("Avatar subido:", res.data);

  return res.data;
};


export const updatePerfil = async (data: { nombre?: string; avatarUrl?: string }) => {
  const res = await api.put('/usuarios/perfil', data)
  return res.data
}
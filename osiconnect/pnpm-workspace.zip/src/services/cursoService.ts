import { api } from "@/services/api";
import { CursoDTO, EventoCursoDTO } from "@/lib/types";

export const getCursoById = async (cursoId: string): Promise<CursoDTO> => {
  const response = await api.get<CursoDTO>(`/cursos/${cursoId}`);
  return response.data;
};

export async function crearEventoCurso(cursoId: string, evento: EventoCursoDTO) {
  const response = await api.post(`/cursos/${cursoId}/evento`, evento);
  return response.data;
}

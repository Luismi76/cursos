"use client";

import React, { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Toaster } from "@/components/ui/sonner";
import { useRol } from "@/hooks/useRol";
import { ArrowLeft, MessageCircle, Book } from "lucide-react";
import clsx from "clsx";
import { UserDropdown } from "@/components/ui/UserDropdown";
import {
  getMensajesCurso,
  getMensajesNoLeidos,
  marcarMensajesCursoComoLeidos,
  enviarMensajeCurso,
} from "@/services/chatCursoService";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { useAuthStore } from "@/hooks/authStore";
import type { MensajeCursoDTO } from "@/lib/types";

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const rol = useRol();
  const user = useAuthStore((state) => state.usuario);
  const match = pathname.match(/\/curso\/([^/]+)/);
  const cursoId = match?.[1];

  const [mensajes, setMensajes] = useState<MensajeCursoDTO[]>([]);
  const [noLeidos, setNoLeidos] = useState<number>(0);
  const [nuevoMensaje, setNuevoMensaje] = useState<string>("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!cursoId) return;

    const cargarMensajes = async () => {
      const [msjs, sinLeer] = await Promise.all([
        getMensajesCurso(cursoId),
        getMensajesNoLeidos(cursoId),
      ]);
      setMensajes(msjs);
      setNoLeidos(sinLeer);
    };

    cargarMensajes();
    const interval = setInterval(cargarMensajes, 10000);
    return () => clearInterval(interval);
  }, [cursoId]);

  const handleEnviarMensaje = async () => {
    if (!nuevoMensaje.trim() || !cursoId) return;

    const contenido = nuevoMensaje.trim();
    setNuevoMensaje("");

    setMensajes((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        contenido,
        fechaEnvio: new Date().toISOString(),
        autor: {
          nombre: user?.nombre || "Tú",
          avatarUrl: user?.avatarUrl || "/avatar.svg", // ✅ AÑADE ESTO
          id: user?.id, // opcional
        },
      } as MensajeCursoDTO,
    ]);

    try {
      await enviarMensajeCurso(cursoId, contenido);
    } catch (error) {
      console.error("Error enviando mensaje:", error);
    }
  };

  const esInicio =
    pathname === "/alumno" ||
    pathname === "/profesor" ||
    pathname === "/dashboard" ||
    pathname === "/admin";

  const home =
    rol === "ALUMNO"
      ? "/alumno"
      : rol === "PROFESOR"
      ? "/profesor"
      : rol === "ADMINISTRADOR"
      ? "/admin"
      : "/";

  return (
    <>
      <header className="flex items-center justify-between bg-background border-b border-border px-4 py-3 shadow-sm w-full">
        <div className="flex items-center gap-4">
          {!esInicio && (
            <button
              onClick={() => router.back()}
              className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1"
            >
              <ArrowLeft className="w-4 h-4" /> Volver
            </button>
          )}

          <Link
            href={home}
            className="text-lg font-semibold text-primary hover:underline"
          >
            SysConnect
          </Link>
        </div>

        <div className="flex items-center gap-4">
          {cursoId && (
            <>
              <Popover
                onOpenChange={(open) => {
                  if (open && cursoId) {
                    marcarMensajesCursoComoLeidos(cursoId);
                    setNoLeidos(0);
                    setTimeout(() => inputRef.current?.focus(), 100);
                  }
                }}
              >
                <PopoverTrigger asChild>
                  <button className="relative text-muted-foreground hover:text-primary transition">
                    <MessageCircle className="w-6 h-6" />
                    {noLeidos > 0 && (
                      <Badge className="absolute -top-1 -right-1 text-[10px] h-4 px-1.5 bg-red-500 text-white">
                        {noLeidos}
                      </Badge>
                    )}
                  </button>
                </PopoverTrigger>
                <PopoverContent className="max-w-md w-[350px] p-4 max-h-96 overflow-auto">
                  <h4 className="font-semibold mb-2 text-sm">Chat del curso</h4>
                  <div className="space-y-2 text-sm mb-2 max-h-52 overflow-y-auto pr-1">
                    {mensajes.length === 0 ? (
                      <p className="text-muted-foreground text-xs">
                        No hay mensajes aún.
                      </p>
                    ) : (
                      mensajes.map((msg) => {
                        const esPropio = msg.autor.nombre === user?.nombre;
                        return (
                          <div
                            key={msg.id}
                            className={clsx(
                              "flex flex-col gap-1 text-sm",
                              esPropio ? "items-end" : "items-start"
                            )}
                          >
                            <div
                              className={clsx(
                                "max-w-[80%] px-3 py-1 rounded-lg shadow-sm",
                                esPropio
                                  ? "bg-blue-100 text-right"
                                  : "bg-gray-100 text-left"
                              )}
                            >
                              <div className="flex items-center gap-2">
                                <img
                                  src={msg.autor.avatarUrl || "/avatar.svg"}
                                  alt={msg.autor.nombre}
                                  className="h-8 w-8 rounded-full"
                                />
                                <div className="flex flex-col">
                                  <div className="font-medium text-xs text-muted-foreground">
                                    {msg.autor.nombre}
                                  </div>
                                  <div>{msg.contenido}</div>
                                  <div className="text-[10px] text-muted-foreground mt-1">
                                    {new Date(msg.fechaEnvio).toLocaleString()}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                  <div className="mt-2">
                    <input
                      ref={inputRef}
                      type="text"
                      value={nuevoMensaje}
                      onChange={(e) => setNuevoMensaje(e.target.value)}
                      onKeyDown={(e) =>
                        e.key === "Enter" && handleEnviarMensaje()
                      }
                      placeholder="Escribe un mensaje..."
                      className="w-full text-sm px-2 py-1 border rounded mb-2"
                    />
                    <button
                      onClick={handleEnviarMensaje}
                      className="bg-primary text-white text-sm px-3 py-1 rounded w-full"
                    >
                      Enviar
                    </button>
                  </div>
                </PopoverContent>
              </Popover>

              <Link
                href={`/curso/${cursoId}/wiki`}
                className="text-sm text-muted-foreground hover:text-primary transition"
              >
                <Book className="w-6 h-6" />
              </Link>
            </>
          )}

          <UserDropdown />
        </div>
      </header>

      <main className="p-4 max-w-screen-xl mx-auto">{children}</main>

      <footer className="fixed bottom-0 left-0 right-0 z-50 md:hidden border-t border-border bg-background shadow-sm">
        <nav className="flex justify-around items-center h-14 text-sm text-muted-foreground">
          <Link
            href={home}
            className={clsx("flex flex-col items-center gap-1", {
              "text-primary": pathname === home,
            })}
          >
            <span>🏠</span>
            <span>Inicio</span>
          </Link>

          {cursoId && (
            <Link
              href={`/curso/${cursoId}/wiki`}
              className="flex flex-col items-center gap-1"
            >
              <span>📚</span>
              <span>Wiki</span>
            </Link>
          )}
        </nav>
      </footer>

      <Toaster />
    </>
  );
}

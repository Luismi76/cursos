'use client'

import { Curso } from "@/lib/types"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface TarjetaCursoProps {
  curso: Curso
  href: string
  botonTexto?: string
}

export function TarjetaCurso({ curso, href, botonTexto = "Ver prácticas" }: TarjetaCursoProps) {
  return (
    <Card className="h-full flex flex-col justify-between hover:shadow-md transition-shadow">
      <CardHeader>
        <CardTitle className="text-lg">{curso.nombre}</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col justify-between space-y-4">
        <p className="text-sm text-muted-foreground">{curso.descripcion}</p>
        <div className="mt-auto">
          <Link href={href}>
            <Button variant="outline" className="w-full">{botonTexto}</Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}

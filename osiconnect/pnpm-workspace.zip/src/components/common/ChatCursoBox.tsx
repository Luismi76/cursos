"use client";

import { useEffect, useRef, useState } from "react";
import { createChatCursoSocket } from "@/hooks/useChatCursoSocket";
import { obtenerMensajesCurso } from "@/services/chatCursoService";
import { MensajeCursoDTO } from "@/lib/types";

export default function ChatCursoBox({
  cursoId,
  usuarioId,
}: {
  cursoId: string;
  usuarioId: string;
}) {
  const [mensajes, setMensajes] = useState<MensajeCursoDTO[]>([]);
  const [texto, setTexto] = useState("");
  const [conectado, setConectado] = useState(false);
  const socketRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    obtenerMensajesCurso(cursoId).then(setMensajes);

    socketRef.current = createChatCursoSocket(
      cursoId,
      (msg: MensajeCursoDTO) => {
        setMensajes((prev) => [...prev, msg]);
      },
      () => setConectado(true)
    );
    return () => socketRef.current?.deactivate();
  }, [cursoId]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [mensajes]);

  const enviar = () => {
    if (!texto.trim() || !conectado) return;

    socketRef.current.publish({
      destination: "/app/curso-chat",
      body: JSON.stringify({
        cursoId,
        emisorId: usuarioId,
        contenido: texto,
      }),
    });

    setTexto("");
  };
  

  return (
    <div className="p-4 border rounded w-full max-w-3xl mx-auto">
      <div className="h-96 overflow-y-auto mb-4 border p-2 bg-white">
        {mensajes.map((m, i) => (
          <div
            key={i}
            className={`flex items-start gap-2 my-2 ${
              m.autor.id === usuarioId ? "justify-end" : "justify-start"
            }`}
          >
            {m.autor.id !== usuarioId && (
              <img
                src={m.autor.avatarUrl || "/avatar.png"}
                alt="avatar"
                className="w-8 h-8 rounded-full object-cover"
              />
            )}
            <div
              className={`inline-block px-3 py-2 rounded-lg ${
                m.autor.id === usuarioId
                  ? "bg-blue-100 text-right"
                  : "bg-gray-200 text-left"
              }`}
            >
              <strong className="block text-sm">{m.autor.nombre}</strong>
              <span className="text-sm">{m.contenido}</span>
            </div>
            {m.autor.id === usuarioId && (
              <img
                src={m.autor.avatarUrl || "/avatar.png"}
                alt="avatar"
                className="w-8 h-8 rounded-full object-cover"
              />
            )}
          </div>
        ))}

        <div ref={scrollRef} />
      </div>
      <div className="flex gap-2">
        <input
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          className="flex-1 border p-1"
          placeholder={
            conectado ? "Escribe un mensaje al grupo..." : "Conectando..."
          }
          disabled={!conectado}
        />
        <button
          onClick={enviar}
          className="px-4 py-1 bg-blue-600 text-white rounded disabled:opacity-50"
          disabled={!conectado || !texto.trim()}
        >
          Enviar
        </button>
      </div>
    </div>
  );
}

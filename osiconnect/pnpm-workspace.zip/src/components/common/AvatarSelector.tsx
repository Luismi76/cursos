import { useEffect, useState } from "react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import clsx from "clsx";

const seeds = ["luna", "mateo", "olivia", "leo", "ines", "nico"];
const styles = ["personas", "lorelei", "fun-emoji"];

interface Props {
  onSelect: (url: string) => void;
  selected: string;
}

export default function AvatarSelector({ onSelect, selected }: Props) {
  const [selectedSeed, setSelectedSeed] = useState(seeds[0]);
  const [selectedStyle, setSelectedStyle] = useState(styles[0]);

  const avatarUrl = `https://api.dicebear.com/7.x/${selectedStyle}/svg?seed=${selectedSeed}`;

  useEffect(() => {
    onSelect(avatarUrl); // Al cambiar selección, actualiza sin guardar aún
  }, [selectedSeed, selectedStyle]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <label className="text-sm text-muted-foreground">Estilo:</label>
        <select
          value={selectedStyle}
          onChange={(e) => setSelectedStyle(e.target.value)}
          className="border px-2 py-1 rounded text-sm"
        >
          {styles.map((style) => (
            <option key={style} value={style}>
              {style}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
        {seeds.map((seed) => {
          const url = `https://api.dicebear.com/7.x/${selectedStyle}/svg?seed=${seed}`;
          const isSelected = selected === url;
          return (
            <button
              key={seed}
              type="button"
              onClick={() => {
                setSelectedSeed(seed);
              }}
              className={clsx(
                "flex flex-col items-center gap-1 p-1 border rounded hover:shadow",
                isSelected ? "border-blue-500 ring-2 ring-blue-300" : ""
              )}
            >
              <img
                src={url}
                alt={seed}
                className="w-16 h-16 rounded-full border object-cover"
              />
              <span className="text-xs text-muted-foreground">{seed}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

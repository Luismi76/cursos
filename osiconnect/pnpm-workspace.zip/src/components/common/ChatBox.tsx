'use client';

import { useEffect, useRef, useState } from 'react';
import { createChatSocket } from '@/hooks/useChatSocket';
import { obtenerMensajes } from '@/services/chatService';

interface ChatMessage {
  emisorId: string;
  receptorId: string;
  contenido: string;
}

export default function ChatBox({
  userId,
  receptorId,
}: {
  userId: string;
  receptorId: string;
}) {
  const [mensajes, setMensajes] = useState<ChatMessage[]>([]);
  const [texto, setTexto] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    obtenerMensajes(userId, receptorId)
      .then((data) => setMensajes(data))
      .catch((error) => {
        console.error('Error al obtener mensajes:', error);
      });

    socketRef.current = createChatSocket(
      userId,
      (msg: ChatMessage) => {
        setMensajes((prev) => [...prev, msg]);
      },
      () => setIsConnected(true)
    );

    return () => socketRef.current?.deactivate();
  }, [userId, receptorId]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mensajes]);

  const enviar = () => {
    if (!texto.trim() || !isConnected) return;

    const msg: ChatMessage = { emisorId: userId, receptorId, contenido: texto };
    socketRef.current.publish({
      destination: '/app/chat',
      body: JSON.stringify(msg),
    });

    setMensajes((prev) => [...prev, msg]);
    setTexto('');
  };

  return (
    <div className="p-4 border rounded w-full max-w-md mx-auto">
      <div className="h-64 overflow-y-auto mb-4 border p-2 bg-white">
        {mensajes.map((m, i) => (
          <div key={i} className={m.emisorId === userId ? 'text-right' : 'text-left'}>
            <span className="inline-block px-2 py-1 rounded bg-gray-200 m-1">
              {m.contenido}
            </span>
          </div>
        ))}
        <div ref={scrollRef} />
      </div>
      <div className="flex gap-2">
        <input
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          className="flex-1 border p-1"
          placeholder={isConnected ? 'Escribe un mensaje...' : 'Conectando...'}
          disabled={!isConnected}
        />
        <button
          onClick={enviar}
          className="px-4 py-1 bg-blue-600 text-white rounded disabled:opacity-50"
          disabled={!isConnected || !texto.trim()}
        >
          Enviar
        </button>
      </div>
    </div>
  );
}

// sin "use client"
import { Curso, EntregaPractica, EntregasAgrupadas } from "@/lib/types";
import ListaPracticasCurso from "@/components/practicas/ListaPracticasCurso";
import CalendarioCurso from "../common/CalendarioCurso";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Clock, CheckCircle } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

type Props = {
  cursoId: string;
  curso: Curso;
  entregas: EntregaPractica[];
  historial: EntregasAgrupadas | null;
};

export default function CursoAlumnoPage({ cursoId, curso, entregas, historial }: Props) {
  return (
    <div className="flex flex-col min-h-screen p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold mb-1">{curso.nombre}</h1>
      <p className="text-muted-foreground text-sm mb-4">
        {curso.descripcion || "Sin descripción"}
      </p>

      <Tabs defaultValue="secuenciacion" className="space-y-6">
        <TabsList>
          <TabsTrigger value="secuenciacion">Secuenciación</TabsTrigger>
          <TabsTrigger value="practicas">Prácticas</TabsTrigger>
          <TabsTrigger value="estado">Estado de entregas</TabsTrigger>
        </TabsList>

        <TabsContent value="secuenciacion">
          <CalendarioCurso
            cursoId={cursoId}
            modo="alumno"
            practicas={curso.practicas?.map((p) => ({
              id: p.id,
              titulo: p.titulo,
              fechaEntrega: p.fechaEntrega,
            }))}
          />
        </TabsContent>

        <TabsContent value="practicas">
          <h2 className="text-xl font-semibold mb-2">Tus prácticas</h2>
          {curso.practicas && curso.practicas.length > 0 ? (
            <ListaPracticasCurso
              practicas={curso.practicas}
              rol="alumno"
              cursoId={curso.id}
              entregas={entregas}
            />
          ) : (
            <p className="text-sm text-muted-foreground">
              Este curso no tiene prácticas.
            </p>
          )}
        </TabsContent>

        <TabsContent value="estado">
          {historial && (
            <section className="space-y-4">
              <h2 className="text-xl font-semibold">
                ⏱️ Estado de tus entregas
              </h2>
              {/* tarjetas entregadas, pendientes, fuera de plazo (igual que antes) */}
            </section>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

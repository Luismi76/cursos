import { Practica, EntregaPractica } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarDays, Pencil, Trash2, Send, FileText } from "lucide-react";
import Link from "next/link";
import RenderEditorContent from "./RenderEditorContent";

interface Props {
  practica: Practica;
  rol: "profesor" | "alumno";
  onEditar?: () => void;
  onEliminar?: () => void;
  cursoId?: string;
  entrega?: EntregaPractica | null;
}

export default function TarjetaPractica({
  practica,
  rol,
  onEditar,
  onEliminar,
  cursoId,
  entrega,
}: Props) {
  const fechaEntrega = new Date(practica.fechaEntrega);

  return (
    <Card className="border-l-4 border-blue-500 shadow-sm">
      <CardContent className="p-4 space-y-2">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold">{practica.titulo}</h3>
          {rol === "profesor" && (
            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={onEditar}>
                <Pencil className="w-4 h-4" />
              </Button>
              <Button variant="destructive" size="icon" onClick={onEliminar}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>

        {typeof practica.descripcion === "string" && (
          <RenderEditorContent data={JSON.parse(practica.descripcion)} />
        )}

        <div className="text-sm flex items-center gap-2 text-gray-500">
          <CalendarDays className="w-4 h-4" />
          Entrega: <span className="text-blue-600">{fechaEntrega.toLocaleDateString()}</span>
        </div>

        <div className="pt-2">
          {rol === "profesor" && (
            <Link href={`/profesor/practica/${practica.id}/entregas`}>
              <Button variant="secondary">Ver entregas</Button>
            </Link>
          )}

          {rol === "alumno" && cursoId && (
            <Link href={`/alumno/curso/${cursoId}/practica/${practica.id}`}>
              <Button variant="outline" className="flex items-center gap-2">
                {entrega ? (
                  <>
                    <Send className="w-4 h-4" /> Entregada
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4" /> Completar
                  </>
                )}
              </Button>
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

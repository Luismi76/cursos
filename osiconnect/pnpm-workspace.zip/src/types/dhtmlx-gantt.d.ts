declare module "dhtmlx-gantt" {
  const gantt: any;
  export default gantt;
}

declare module "frappe-gantt" {
  const Gantt: any;
  export default Gantt;
}

"use client";

import { useEffect, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  getPerfil,
  actualizarPerfil,
  subirAvatar,
} from "@/services/usuarioService";
import AvatarGallerySelector from "@/components/common/AvatarCustomizer";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import AvatarAmpliable from "@/components/common/AvatarAmpliable";

export default function PerfilPage() {
  const [nombre, setNombre] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [originalNombre, setOriginalNombre] = useState("");
  const [originalAvatarUrl, setOriginalAvatarUrl] = useState("");
  const [email, setEmail] = useState("");
  const [rol, setRol] = useState("");
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getPerfil().then((data) => {
      setNombre(data.nombre);
      setAvatarUrl(data.avatarUrl || "");
      setOriginalNombre(data.nombre);
      setOriginalAvatarUrl(data.avatarUrl || "");
      setEmail(data.email);
      setRol(data.rol);
    });
  }, []);
  console.log("avatarUrl", avatarUrl);
  const hayCambios =
    nombre !== originalNombre || avatarUrl !== originalAvatarUrl;

  const handleActualizar = async () => {
    try {
      await actualizarPerfil({ nombre, avatarUrl });
      toast.success("Perfil actualizado correctamente");
      setOriginalNombre(nombre);
      setOriginalAvatarUrl(avatarUrl);
    } catch (err) {
      console.error(err);
      toast.error("Error al actualizar el perfil");
    }
  };

  const handleSeleccionarArchivo = () => {
    fileInputRef.current?.click();
  };

  const handleArchivoSeleccionado = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      setLoading(true);
      const nuevaUrl = await subirAvatar(file);
      setAvatarUrl(nuevaUrl);
    } catch (err) {
      console.error(err);
      toast.error("Error al subir el avatar");
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarGenerado = (url: string) => {
    setAvatarUrl(url); // No guardar automáticamente
  };

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-8">
      <div className="flex items-center gap-2 text-sm">
        <Link
          href="/profesor"
          className="inline-flex items-center gap-1 text-blue-600 hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Volver
        </Link>
      </div>

      <h1 className="text-2xl font-bold">Mi perfil</h1>

      <div className="bg-card border rounded-lg p-6 space-y-6 shadow-sm">
        <div className="flex items-center gap-6">
          <AvatarAmpliable
            url={avatarUrl}
            alt={`Avatar de ${nombre}`}
            nombre={nombre}
            size={80}
          />
          <div className="space-y-2">
            <Button
              type="button"
              onClick={handleSeleccionarArchivo}
              disabled={loading}
            >
              {loading ? "Subiendo..." : "Subir imagen"}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleArchivoSeleccionado}
            />
            <p className="text-sm text-muted-foreground">
              También puedes elegir un avatar predefinido:
            </p>
          </div>
        </div>

        <div className="grid gap-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">
              Email
            </p>
            <p>{email}</p>
          </div>

          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">
              Rol
            </p>
            <p>
              {rol === "PROFESOR"
                ? "Profesor"
                : rol === "ALUMNO"
                ? "Alumno"
                : "Administrador"}
            </p>
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground block mb-1">
              Nombre
            </label>
            <Input
              placeholder="Tu nombre"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
            />
          </div>
        </div>

        <div className="pt-2">
          <AvatarGallerySelector onSelect={handleAvatarGenerado} />
        </div>

        {hayCambios && (
          <div className="pt-4 text-right">
            <Button onClick={handleActualizar}>Guardar cambios</Button>
          </div>
        )}
      </div>
    </div>
  );
}

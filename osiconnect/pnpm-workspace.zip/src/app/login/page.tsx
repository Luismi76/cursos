"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { login } from "@/hooks/authService";
import { useAuthStore } from "@/hooks/authStore";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();
  const setUser = useAuthStore((state) => state.setUser);

  const handleLogin = async () => {
    try {
      const { token, user } = await login(email, password);

      // ✅ GUARDAMOS el token para futuras peticiones
      localStorage.setItem("token", token);

      // ✅ Actualizamos el store
      setUser(user);

      // ✅ Redirigimos por rol
      if (user.rol === "ADMINISTRADOR") {
        router.push("/admin");
      } else if (user.rol === "PROFESOR") {
        router.push("/profesor");
      } else if (user.rol === "ALUMNO") {
        router.push("/alumno");
      } else {
        alert("Rol no reconocido");
      }
    } catch (e) {
      alert("Login incorrecto");
    }
  };

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-xl font-bold mb-4">Iniciar sesión</h1>
      <Input
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email"
      />
      <Input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Contraseña"
        className="mt-2"
      />
      <Button onClick={handleLogin} className="mt-4 w-full">
        Entrar
      </Button>
    </div>
  );
}

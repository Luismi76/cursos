"use client";

import { useEffect, useState } from "react";
import { getCursosProfesor } from "@/services/profesorService";
import { getPerfil, updatePerfil } from "@/services/usuarioService";
import { TarjetaCurso } from "@/components/cursos/TarjetaCurso";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import type { Curso, Usuario } from "@/lib/types";
import Link from "next/link";
import AvatarAmpliable from "@/components/common/AvatarAmpliable";

export default function PaginaInicioProfesor() {
  const [perfil, setPerfil] = useState<Usuario | null>(null);
  const [cursos, setCursos] = useState<Curso[]>([]);
  const [editando, setEditando] = useState(false);
  const [nombre, setNombre] = useState("");

  useEffect(() => {
    getPerfil()
      .then(setPerfil)
      .catch(() => toast.error("Error al cargar perfil"));
    getCursosProfesor()
      .then(setCursos)
      .catch(() => toast.error("Error al cargar cursos"));
  }, []);

  useEffect(() => {
    if (perfil) setNombre(perfil.nombre);
  }, [perfil]);

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {perfil && (
        <div className="flex items-center gap-4 border p-4 rounded shadow-sm">
          <AvatarAmpliable
            url={perfil.avatarUrl}
            nombre={perfil.nombre}
            alt="Avatar en dropdown"
            size={180}
            ampliable={true}
          />
          <div className="flex-1">
            <h2 className="text-lg font-semibold">{perfil.nombre}</h2>
            <p className="text-sm text-muted-foreground">{perfil.email}</p>
          </div>
          <Link href="/perfil">
            <Button variant="outline">Editar perfil</Button>
          </Link>
        </div>
      )}

      <section>
        <h1 className="text-2xl font-bold mb-4">Mis cursos</h1>
        {cursos.length === 0 ? (
          <p className="text-muted-foreground">No tienes cursos asignados.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {cursos.map((curso) => (
              <TarjetaCurso
                key={curso.id}
                curso={curso}
                href={`/profesor/curso/${curso.id}`}
                botonTexto="Ver curso"
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
